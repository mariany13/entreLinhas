import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/theme/colors.dart';
import 'core/theme/literatura_data.dart';
import 'presentation/pages/appbar/home_page1.dart';
import 'presentation/pages/appbar/home_page2.dart';
import 'presentation/pages/text/home_page1.dart';
import 'presentation/pages/text/home_page2.dart' as quiz_pages;
import 'presentation/pages/text/home_page3.dart';
import 'presentation/pages/text/home_page4.dart';
import 'presentation/widgets/common.dart';

class LiteratureApp extends StatelessWidget {
  const LiteratureApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'EntreLinhas',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: cyan,
          brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: bg,
          foregroundColor: cyan,
          elevation: 0,
        ),
        useMaterial3: true,
      ),
      home: const AppRoot(),
    );
  }
}

class AppRoot extends StatefulWidget {
  const AppRoot({super.key});

  @override
  State<AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<AppRoot> {
  List<Movement> movements = <Movement>[];
  List<Question> generalQuiz = <Question>[];
  final Set<String> completedLessons = <String>{};

  String phase = 'splash';
  String userName = 'Estudante';
  String tab = 'home';
  Movement? selectedMovement;
  Lesson? selectedLesson;
  List<Question>? quizQuestions;
  List<Question> lastQuizQuestions = <Question>[];
  String quizTitle = '';
  int quizStep = 0;
  int score = 0;
  int? selectedAnswer;
  bool answered = false;
  bool showingResult = false;
  int resultScore = 0;
  int resultTotal = 0;
  int totalQuizAnswers = 0;
  int totalCorrectAnswers = 0;
  bool loading = true;
  String? loadError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final loadedMovements = await loadMovements();
      final loadedQuiz = await loadGeneralQuiz();

      final savedLessons = prefs.getStringList('completedLessons') ?? <String>[];
      final savedName = prefs.getString('userName');

      if (!mounted) return;
      setState(() {
        movements = loadedMovements;
        generalQuiz = loadedQuiz;
        completedLessons.addAll(savedLessons);
        userName = savedName?.trim().isNotEmpty == true ? savedName! : 'Estudante';
        totalQuizAnswers = prefs.getInt('totalQuizAnswers') ?? 0;
        totalCorrectAnswers = prefs.getInt('totalCorrectAnswers') ?? 0;
        loading = false;
      });
    } catch (error) {
      debugPrint('Erro ao carregar conteúdo: $error');
      if (!mounted) return;
      setState(() {
        loading = false;
        loadError = 'Não foi possível carregar o conteúdo.';
      });
    }
  }

  int get totalLessons => movements.fold(
        0,
        (sum, movement) => sum + movement.lessons.length,
      );

  int get totalCompleted => movements
      .expand((movement) => movement.lessons)
      .where((lesson) => completedLessons.contains(lesson.id))
      .length;

  int get accuracy => totalQuizAnswers == 0
      ? 0
      : ((totalCorrectAnswers / totalQuizAnswers) * 100).round();

  Future<void> _saveProgress() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('completedLessons', completedLessons.toList());
    await prefs.setString('userName', userName);
    await prefs.setInt('totalQuizAnswers', totalQuizAnswers);
    await prefs.setInt('totalCorrectAnswers', totalCorrectAnswers);
  }

  void openMovement(Movement movement) => setState(() => selectedMovement = movement);

  void openLesson(Lesson lesson) {
    final movement = selectedMovement;
    final index = movement?.lessons.indexWhere((item) => item.id == lesson.id) ?? -1;
    final previous = index > 0 ? movement!.lessons[index - 1] : null;
    final unlocked = !lesson.locked || previous == null || completedLessons.contains(previous.id);

    if (!unlocked) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Conclua a aula anterior para desbloquear esta aula.'),
        ),
      );
      return;
    }
    setState(() => selectedLesson = lesson);
  }

  void startQuiz(String title, List<Question> questions) {
    if (questions.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Este quiz ainda não possui questões.')),
      );
      return;
    }

    setState(() {
      // Fecha qualquer tela anterior antes de abrir o quiz.
      // Isso evita que a tela do movimento fique sobre o quiz.
      selectedMovement = null;
      selectedLesson = null;
      quizTitle = title;
      quizQuestions = List<Question>.from(questions);
      lastQuizQuestions = List<Question>.from(questions);
      quizStep = 0;
      score = 0;
      selectedAnswer = null;
      answered = false;
      showingResult = false;
    });
  }

  void chooseAnswer(int index) {
    if (answered || quizQuestions == null) return;
    setState(() => selectedAnswer = index);
  }

  Future<void> nextQuestion() async {
    if (quizQuestions == null || selectedAnswer == null) return;

    final question = quizQuestions![quizStep];

    if (!answered) {
      final correct = selectedAnswer == question.correct;
      setState(() {
        answered = true;
        if (correct) score++;
        totalQuizAnswers++;
        if (correct) totalCorrectAnswers++;
      });
      await _saveProgress();
      return;
    }

    if (quizStep + 1 >= quizQuestions!.length) {
      setState(() {
        resultScore = score;
        resultTotal = quizQuestions!.length;
        showingResult = true;
        quizQuestions = null;
      });
    } else {
      setState(() {
        quizStep++;
        selectedAnswer = null;
        answered = false;
      });
    }
  }

  Future<void> completeLesson(Lesson lesson) async {
    if (completedLessons.contains(lesson.id)) return;

    setState(() => completedLessons.add(lesson.id));
    await _saveProgress();
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('userName');

    if (!mounted) return;
    setState(() {
      userName = 'Estudante';
      tab = 'home';
      phase = 'login';
      selectedMovement = null;
      selectedLesson = null;
      quizQuestions = null;
      showingResult = false;
    });
  }

  void back() {
    if (selectedLesson != null) {
      setState(() => selectedLesson = null);
      return;
    }
    if (selectedMovement != null) {
      setState(() => selectedMovement = null);
      return;
    }
    if (quizQuestions != null) {
      setState(() => quizQuestions = null);
      return;
    }
    if (showingResult) {
      setState(() => showingResult = false);
      return;
    }
    setState(() => phase = 'app');
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const LoadingPage();
    if (loadError != null) {
      return ErrorPage(message: loadError!, onRetry: _load);
    }

    if (phase == 'splash') {
      return SplashPage(onContinue: () => setState(() => phase = 'login'));
    }

    if (phase == 'login') {
      return LoginPage(
        onLogin: (name) async {
          setState(() {
            userName = name;
            phase = 'app';
          });
          await _saveProgress();
        },
        onRegister: () => setState(() => phase = 'register'),
      );
    }

    if (phase == 'register') {
      return RegisterPage(
        onBack: () => setState(() => phase = 'login'),
        onRegister: (name) async {
          setState(() {
            userName = name;
            phase = 'app';
          });
          await _saveProgress();
        },
      );
    }

    if (selectedLesson != null) {
      return LessonPage(
        lesson: selectedLesson!,
        onBack: back,
        completed: completedLessons.contains(selectedLesson!.id),
        onComplete: () => completeLesson(selectedLesson!),
      );
    }

    if (selectedMovement != null) {
      final movement = selectedMovement!;
      return MovementDetailPage(
        movement: movement,
        completedLessons: completedLessons,
        onBack: back,
        onLesson: openLesson,
        onQuiz: () => startQuiz('Quiz · ${movement.title}', movement.quiz),
      );
    }

    if (quizQuestions != null) {
      return quiz_pages.QuizPage(
        title: quizTitle,
        questions: quizQuestions!,
        step: quizStep,
        selected: selectedAnswer,
        answered: answered,
        score: score,
        onAnswer: chooseAnswer,
        onNext: nextQuestion,
        onBack: back,
      );
    }

    if (showingResult) {
      return ResultPage(
        title: quizTitle,
        score: resultScore,
        total: resultTotal,
        onBack: back,
        onRetry: () => startQuiz(quizTitle, lastQuizQuestions),
      );
    }

    Widget body;
    if (tab == 'movements') {
      body = MovementsPage(
        movements: movements,
        onMovement: openMovement,
      );
    } else if (tab == 'profile') {
      body = ProfilePage(
        movements: movements,
        userName: userName,
        totalCompleted: totalCompleted,
        totalLessons: totalLessons,
        completedLessons: completedLessons,
        accuracy: accuracy,
        onLogout: logout,
      );
    } else {
      body = HomePage(
        movements: movements,
        userName: userName,
        totalCompleted: totalCompleted,
        totalLessons: totalLessons,
        completedLessons: completedLessons,
        onMovement: openMovement,
        onQuiz: () => startQuiz('Quiz Geral', generalQuiz),
      );
    }

    return Scaffold(
      body: body,
      bottomNavigationBar: BottomNav(
        active: tab,
        onChange: (value) => setState(() => tab = value),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  final List<Movement> movements;
  final String userName;
  final int totalCompleted;
  final int totalLessons;
  final Set<String> completedLessons;
  final int accuracy;
  final VoidCallback onLogout;

  const ProfilePage({
    super.key,
    required this.movements,
    required this.userName,
    required this.totalCompleted,
    required this.totalLessons,
    required this.completedLessons,
    required this.accuracy,
    required this.onLogout,
  });

  @override
  Widget build(BuildContext context) {
    final initials = userName
        .split(' ')
        .where((part) => part.isNotEmpty)
        .map((part) => part[0])
        .take(2)
        .join()
        .toUpperCase();

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 30),
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 25, 20, 20),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF00171F), bg],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 32,
                      backgroundColor: gold,
                      child: Text(
                        initials.isEmpty ? 'E' : initials,
                        style: const TextStyle(
                          color: bg,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ),
                    const SizedBox(width: 15),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            userName,
                            style: const TextStyle(
                              color: cream,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const Text(
                            'Estudante · EntreLinhas',
                            style: TextStyle(color: muted, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: 'Sair',
                      onPressed: onLogout,
                      icon: const Icon(Icons.logout_outlined, color: muted),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Stat(label: 'Aulas', value: '$totalCompleted', icon: Icons.menu_book),
                    Stat(label: 'Progresso', value: totalLessons == 0 ? '0%' : '${((totalCompleted / totalLessons) * 100).round()}%', icon: Icons.trending_up),
                    Stat(label: 'Acertos', value: '$accuracy%', icon: Icons.workspace_premium),
                  ],
                ),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 20, 20, 10),
            child: SectionTitle('PROGRESSO POR MOVIMENTO'),
          ),
          ...movements.map((movement) {
            final completed = movement.lessons
                .where((lesson) => completedLessons.contains(lesson.id))
                .length;
            final progress = movement.lessons.isEmpty
                ? 0.0
                : (completed / movement.lessons.length).toDouble();

            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
              child: Row(
                children: [
                  Text(movement.emoji, style: const TextStyle(fontSize: 20)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(movement.title, style: const TextStyle(color: cream, fontSize: 12)),
                            Text('${(progress * 100).round()}%', style: const TextStyle(color: muted, fontSize: 11)),
                          ],
                        ),
                        const SizedBox(height: 4),
                        LinearProgressIndicator(
                          value: progress,
                          minHeight: 5,
                          backgroundColor: Colors.white10,
                          valueColor: AlwaysStoppedAnimation<Color>(movement.accent),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }),
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 20, 20, 10),
            child: SectionTitle('CONQUISTAS'),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                BadgeItem('📖', 'Primeira aula', totalCompleted >= 1),
                BadgeItem('🎓', '10 aulas', totalCompleted >= 10),
                BadgeItem('🏆', 'Quiz com 70%+', accuracy >= 70),
                BadgeItem('🔥', '50% do curso', totalLessons > 0 && totalCompleted >= totalLessons / 2),
                const BadgeItem('⭐', 'Curso completo', false),
                const BadgeItem('💡', 'Especialista', false),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
