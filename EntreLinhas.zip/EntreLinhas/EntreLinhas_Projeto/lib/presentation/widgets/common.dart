import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/literatura_data.dart';

class AppButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  final bool outline;

  const AppButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.outline = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          backgroundColor: outline ? Colors.transparent : gold,
          foregroundColor: outline ? cream : bg,
          side: BorderSide(color: outline ? Colors.white12 : gold),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text(
          label,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
class AuthScaffold extends StatelessWidget {
  final String title;
  final String subtitle;
  final List<Widget> children;
  final VoidCallback? back;

  const AuthScaffold({
    super.key,
    required this.title,
    required this.subtitle,
    required this.children,
    this.back,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 30, 24, 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (back != null)
                IconButton(
                  onPressed: back,
                  icon: const Icon(Icons.arrow_back),
                ),
              const SizedBox(height: 25),
              Center(
                child: Column(
                  children: [
                    const Text('📚', style: TextStyle(fontSize: 42)),
                    const SizedBox(height: 15),
                    Text(
                      title,
                      style: const TextStyle(
                        color: cream,
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      subtitle,
                      style: const TextStyle(color: muted),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 35),
              ...children,
            ],
          ),
        ),
      ),
    );
  }
}
class AppTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final bool obscure;
  final Widget? suffix;
  final TextInputType? keyboardType;

  const AppTextField({
    super.key,
    required this.controller,
    required this.label,
    required this.icon,
    this.obscure = false,
    this.suffix,
    this.keyboardType,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        keyboardType: keyboardType,
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          suffixIcon: suffix,
          filled: true,
          fillColor: panel,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}
class MovementContinueCard extends StatelessWidget {
  final Movement movement;
  final Set<String> completedLessons;
  final VoidCallback onTap;

  const MovementContinueCard({
    super.key,
    required this.movement,
    required this.completedLessons,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final completed = movement.lessons
        .where((lesson) => completedLessons.contains(lesson.id))
        .length;
    final progress = movement.lessons.isEmpty
        ? 0.0
        : (completed / movement.lessons.length).toDouble();

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Card(
        color: panel,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Text(movement.emoji, style: const TextStyle(fontSize: 38)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      movement.title,
                      style: const TextStyle(
                        color: cream,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      movement.shortDesc,
                      style: const TextStyle(color: muted, fontSize: 12),
                    ),
                    const SizedBox(height: 9),
                    LinearProgressIndicator(
                      value: progress,
                      minHeight: 4,
                      backgroundColor: Colors.white10,
                      valueColor: AlwaysStoppedAnimation<Color>(movement.accent),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
class MovementTile extends StatelessWidget {
  final Movement movement;
  final VoidCallback onTap;

  const MovementTile({
    super.key,
    required this.movement,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Card(
        color: panel,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: 45,
                height: 45,
                decoration: BoxDecoration(
                  color: movement.background,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    movement.emoji,
                    style: const TextStyle(fontSize: 22),
                  ),
                ),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      movement.title,
                      style: const TextStyle(
                        color: cream,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      movement.period,
                      style: const TextStyle(color: muted, fontSize: 11),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: muted),
            ],
          ),
        ),
      ),
    );
  }
}
class TabBarLike extends StatelessWidget {
  final int index;
  final List<String> labels;
  final void Function(int index) onChange;

  const TabBarLike({
    super.key,
    required this.index,
    required this.labels,
    required this.onChange,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List<Widget>.generate(labels.length, (itemIndex) {
        final selected = itemIndex == index;
        return Expanded(
          child: GestureDetector(
            onTap: () => onChange(itemIndex),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 13),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: selected ? gold : Colors.white10,
                    width: selected ? 2 : 1,
                  ),
                ),
              ),
              child: Center(
                child: Text(
                  labels[itemIndex],
                  style: TextStyle(
                    color: selected ? gold : muted,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}
class LessonCard extends StatelessWidget {
  final Lesson lesson;
  final VoidCallback? onTap;
  final bool unlocked;
  final bool completed;

  const LessonCard({
    super.key,
    required this.lesson,
    required this.onTap,
    this.unlocked = true,
    this.completed = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Card(
          color: panel,
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Row(
              children: [
                Icon(
                  !unlocked
                      ? Icons.lock_outline
                      : completed
                          ? Icons.check_circle_outline
                          : Icons.play_circle_outline,
                  color: !unlocked
                      ? muted
                      : completed
                          ? cyan
                          : gold,
                  size: 27,
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        lesson.title,
                        style: const TextStyle(
                          color: cream,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        lesson.duration,
                        style: const TextStyle(color: muted, fontSize: 11),
                      ),
                    ],
                  ),
                ),
                Icon(
                  !unlocked ? Icons.lock_outline : Icons.chevron_right,
                  color: muted,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
class Stat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const Stat({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: gold.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Icon(icon, color: gold, size: 18),
            const SizedBox(height: 3),
            Text(
              value,
              style: const TextStyle(
                color: cream,
                fontWeight: FontWeight.bold,
                fontSize: 17,
              ),
            ),
            Text(
              label,
              style: const TextStyle(color: muted, fontSize: 9),
            ),
          ],
        ),
      ),
    );
  }
}
class BadgeItem extends StatelessWidget {
  final String icon;
  final String label;
  final bool earned;

  const BadgeItem(this.icon, this.label, this.earned, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 105,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: earned ? gold.withOpacity(0.10) : panel,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: earned ? gold.withOpacity(0.2) : Colors.white10,
        ),
      ),
      child: Column(
        children: [
          Opacity(
            opacity: earned ? 1 : 0.4,
            child: Text(icon, style: const TextStyle(fontSize: 25)),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(color: earned ? cream : muted, fontSize: 10),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
class BottomNav extends StatelessWidget {
  final String active;
  final void Function(String value) onChange;

  const BottomNav({
    super.key,
    required this.active,
    required this.onChange,
  });

  @override
  Widget build(BuildContext context) {
    const values = ['home', 'movements', 'profile'];
    final selectedIndex = values.indexOf(active).clamp(0, values.length - 1).toInt();

    return NavigationBar(
      backgroundColor: panelDark,
      indicatorColor: gold.withOpacity(0.12),
      selectedIndex: selectedIndex,
      onDestinationSelected: (index) => onChange(values[index]),
      destinations: const [
        NavigationDestination(
          icon: Icon(Icons.home_outlined),
          selectedIcon: Icon(Icons.home),
          label: 'Início',
        ),
        NavigationDestination(
          icon: Icon(Icons.layers_outlined),
          selectedIcon: Icon(Icons.layers),
          label: 'Movimentos',
        ),
        NavigationDestination(
          icon: Icon(Icons.person_outline),
          selectedIcon: Icon(Icons.person),
          label: 'Perfil',
        ),
      ],
    );
  }
}
class SectionTitle extends StatelessWidget {
  final String text;

  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        color: muted,
        fontSize: 11,
        letterSpacing: 2,
        fontWeight: FontWeight.bold,
      ),
    );
  }
}
class Bullet extends StatelessWidget {
  final String text;

  const Bullet(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '• ',
            style: TextStyle(color: gold, fontSize: 16),
          ),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(color: cream, height: 1.45),
            ),
          ),
        ],
      ),
    );
  }
}

class LoadingPage extends StatelessWidget {
  const LoadingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: gold),
            SizedBox(height: 16),
            Text('Carregando conteúdo...', style: TextStyle(color: muted)),
          ],
        ),
      ),
    );
  }
}

class ErrorPage extends StatelessWidget {
  final String message;
  final Future<void> Function() onRetry;

  const ErrorPage({
    super.key,
    required this.message,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, color: gold, size: 48),
              const SizedBox(height: 16),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(color: cream, fontSize: 16),
              ),
              const SizedBox(height: 18),
              AppButton(label: 'Tentar novamente', onPressed: () => onRetry()),
            ],
          ),
        ),
      ),
    );
  }
}
