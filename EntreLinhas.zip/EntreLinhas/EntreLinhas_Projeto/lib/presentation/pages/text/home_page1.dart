import 'package:flutter/material.dart';
import '../../../core/theme/colors.dart';
import '../../../core/theme/literatura_data.dart';
import '../../widgets/common.dart';

class MovementDetailPage extends StatefulWidget {
  final Movement movement;
  final VoidCallback onBack;
  final void Function(Lesson lesson) onLesson;
  final VoidCallback onQuiz;
  final Set<String> completedLessons;

  const MovementDetailPage({
    super.key,
    required this.movement,
    required this.onBack,
    required this.onLesson,
    required this.onQuiz,
    required this.completedLessons,
  });

  @override
  State<MovementDetailPage> createState() => _MovementDetailPageState();
}
class _MovementDetailPageState extends State<MovementDetailPage> {
  int selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    final movement = widget.movement;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  IconButton(
                    onPressed: widget.onBack,
                    icon: const Icon(Icons.arrow_back),
                  ),
                  Row(
                    children: [
                      Text(
                        movement.emoji,
                        style: const TextStyle(fontSize: 32),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              movement.title,
                              style: const TextStyle(
                                color: cream,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              movement.period,
                              style: const TextStyle(color: muted, fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    movement.shortDesc,
                    style: const TextStyle(color: muted),
                  ),
                ],
              ),
            ),
            TabBarLike(
              index: selectedTab,
              labels: const ['Visão geral', 'Aulas', 'Autores'],
              onChange: (index) {
                setState(() => selectedTab = index);
              },
            ),
            Expanded(child: buildTabContent(movement)),
          ],
        ),
      ),
    );
  }

  Widget buildTabContent(Movement movement) {
    if (selectedTab == 1) {
      return ListView(
        padding: const EdgeInsets.all(20),
        children: List<Widget>.generate(movement.lessons.length, (index) {
          final lesson = movement.lessons[index];
          final previous = index == 0 ? null : movement.lessons[index - 1];
          final unlocked = !lesson.locked ||
              previous == null ||
              widget.completedLessons.contains(previous.id);

          return LessonCard(
            lesson: lesson,
            unlocked: unlocked,
            completed: widget.completedLessons.contains(lesson.id),
            onTap: unlocked ? () => widget.onLesson(lesson) : () => widget.onLesson(lesson),
          );
        }),
      );
    }

    if (selectedTab == 2) {
      return ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SectionTitle('PRINCIPAIS AUTORES'),
          ...movement.mainAuthors.map((author) => Bullet(author)),
          const SizedBox(height: 18),
          const SectionTitle('PRINCIPAIS OBRAS'),
          ...movement.mainWorks.map((work) => Bullet(work)),
        ],
      );
    }

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SectionTitle('SOBRE O MOVIMENTO'),
        Text(
          movement.overview,
          style: const TextStyle(color: cream, height: 1.55),
        ),
        const SizedBox(height: 22),
        const SectionTitle('CARACTERÍSTICAS'),
        ...movement.characteristics.map((item) => Bullet(item)),
        const SizedBox(height: 22),
        Card(
          color: movement.background,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              '💡 ${movement.curiosity}',
              style: const TextStyle(color: cream, height: 1.5),
            ),
          ),
        ),
        const SizedBox(height: 18),
        AppButton(
          label: 'Fazer quiz deste movimento',
          onPressed: widget.onQuiz,
        ),
      ],
    );
  }
}
