import 'package:flutter/material.dart';
import '../../../core/theme/colors.dart';
import '../../../core/theme/literatura_data.dart';
import '../../widgets/common.dart';

class QuizPage extends StatelessWidget {
  final String title;
  final List<Question> questions;
  final int step;
  final int? selected;
  final bool answered;
  final int score;
  final void Function(int index) onAnswer;
  final VoidCallback onNext;
  final VoidCallback onBack;

  const QuizPage({
    super.key,
    required this.title,
    required this.questions,
    required this.step,
    required this.selected,
    required this.answered,
    required this.score,
    required this.onAnswer,
    required this.onNext,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    if (questions.isEmpty || step >= questions.length) {
      return Scaffold(
        body: Center(child: AppButton(label: 'Voltar', onPressed: onBack)),
      );
    }

    final question = questions[step];

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Row(
              children: [
                IconButton(
                  tooltip: 'Voltar',
                  onPressed: onBack,
                  icon: const Icon(Icons.arrow_back),
                ),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      color: cream,
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Text(
                  'Pontos: $score',
                  style: const TextStyle(
                    color: cyan,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(width: 15),
              ],
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(
                  value: (step + 1) / questions.length,
                  minHeight: 5,
                  backgroundColor: Colors.white10,
                  valueColor: const AlwaysStoppedAnimation<Color>(cyan),
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'QUESTÃO',
                        style: TextStyle(
                          color: muted,
                          fontSize: 11,
                          letterSpacing: 2,
                        ),
                      ),
                      Text(
                        '${step + 1}/${questions.length}',
                        style: const TextStyle(color: muted),
                      ),
                    ],
                  ),
                  const SizedBox(height: 15),
                  Text(
                    question.question,
                    style: const TextStyle(
                      color: cream,
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                      height: 1.35,
                    ),
                  ),
                  const SizedBox(height: 20),
                  ...List<Widget>.generate(question.options.length, (index) {
                    final isSelected = selected == index;
                    final isCorrect = question.correct == index;
                    Color borderColor = Colors.white10;
                    Color fillColor = panel;

                    if (answered && isCorrect) {
                      borderColor = cyan;
                      fillColor = cyan.withOpacity(0.12);
                    } else if (answered && isSelected) {
                      borderColor = Colors.redAccent;
                      fillColor = Colors.redAccent.withOpacity(0.10);
                    } else if (isSelected) {
                      borderColor = cyan;
                      fillColor = cyan.withOpacity(0.10);
                    }

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: InkWell(
                        onTap: answered ? null : () => onAnswer(index),
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.all(15),
                          decoration: BoxDecoration(
                            color: fillColor,
                            border: Border.all(color: borderColor),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  question.options[index],
                                  style: const TextStyle(
                                    color: cream,
                                    height: 1.3,
                                  ),
                                ),
                              ),
                              if (answered && isCorrect)
                                const Icon(Icons.check_circle, color: cyan),
                              if (answered && isSelected && !isCorrect)
                                const Icon(Icons.cancel, color: Colors.redAccent),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                  if (answered)
                    Card(
                      color: panel,
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Text(
                          question.explanation,
                          style: const TextStyle(color: muted, height: 1.5),
                        ),
                      ),
                    ),
                  const SizedBox(height: 12),
                  if (selected != null && !answered)
                    AppButton(label: 'Responder', onPressed: onNext),
                  if (answered)
                    AppButton(
                      label: step + 1 >= questions.length
                          ? 'Ver resultado'
                          : 'Próxima questão',
                      onPressed: onNext,
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
