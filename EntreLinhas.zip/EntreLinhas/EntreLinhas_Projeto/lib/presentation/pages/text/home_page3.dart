import 'package:flutter/material.dart';
import '../../../core/theme/colors.dart';
import '../../widgets/common.dart';

class ResultPage extends StatelessWidget {
  final String title;
  final int score;
  final int total;
  final VoidCallback onBack;
  final VoidCallback onRetry;

  const ResultPage({
    super.key,
    required this.title,
    required this.score,
    required this.total,
    required this.onBack,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    final rate = total == 0 ? 0.0 : score / total;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(25),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('🏆', style: TextStyle(fontSize: 70)),
                const SizedBox(height: 18),
                const Text(
                  'Quiz concluído!',
                  style: TextStyle(color: cream, fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  '$score de $total acertos',
                  style: const TextStyle(color: cyan, fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(
                  rate >= .7 ? 'Excelente! Continue assim.' : 'Continue estudando e tente novamente.',
                  style: const TextStyle(color: muted),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 30),
                AppButton(label: 'Refazer quiz', onPressed: onRetry),
                const SizedBox(height: 12),
                AppButton(label: 'Voltar aos movimentos', onPressed: onBack, outline: true),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
