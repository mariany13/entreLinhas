import 'package:flutter/material.dart';
import '../../../core/theme/colors.dart';
import '../../../core/theme/literatura_data.dart';
import '../../widgets/common.dart';

class LessonPage extends StatelessWidget {
  final Lesson lesson;
  final VoidCallback onBack;
  final bool completed;
  final VoidCallback onComplete;

  const LessonPage({
    super.key,
    required this.lesson,
    required this.onBack,
    required this.completed,
    required this.onComplete,
  });

  List<Widget> buildContent() {
    final widgets = <Widget>[];
    final blocks = lesson.content.split('\n\n');

    for (final raw in blocks) {
      final text = raw.trim();
      if (text.isEmpty) continue;

      if (text.startsWith('**') && text.endsWith('**')) {
        widgets.add(
          Padding(
            padding: const EdgeInsets.only(top: 16, bottom: 5),
            child: Text(
              text.replaceAll('**', ''),
              style: const TextStyle(
                color: cream,
                fontSize: 19,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        );
      } else if (text.startsWith('*') && text.endsWith('*')) {
        widgets.add(
          Container(
            margin: const EdgeInsets.symmetric(vertical: 10),
            padding: const EdgeInsets.only(left: 14),
            decoration: const BoxDecoration(
              border: Border(left: BorderSide(color: gold, width: 3)),
            ),
            child: Text(
              text.replaceAll('*', ''),
              style: const TextStyle(
                color: Color(0xFFD4B878),
                fontStyle: FontStyle.italic,
                fontSize: 16,
                height: 1.5,
              ),
            ),
          ),
        );
      } else if (text.startsWith('•')) {
        for (final line in text.split('\n')) {
          if (line.trim().isNotEmpty) {
            widgets.add(Bullet(line.replaceFirst('•', '').trim()));
          }
        }
      } else {
        widgets.add(
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(
              text.replaceAll('**', ''),
              style: const TextStyle(
                color: cream,
                height: 1.65,
                fontSize: 15,
              ),
            ),
          ),
        );
      }
    }

    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Row(
              children: [
                IconButton(
                  onPressed: onBack,
                  icon: const Icon(Icons.arrow_back),
                ),
                Expanded(
                  child: Text(
                    lesson.title,
                    style: const TextStyle(
                      color: cream,
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                    ),
                  ),
                ),
                Text(
                  lesson.duration,
                  style: const TextStyle(color: muted, fontSize: 11),
                ),
                const SizedBox(width: 15),
              ],
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(22, 8, 22, 30),
                children: [
                  ...buildContent(),
                  const SizedBox(height: 20),
                  AppButton(
                    label: completed ? '✓ Aula concluída' : 'Marcar aula como concluída',
                    onPressed: completed ? () {} : onComplete,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
