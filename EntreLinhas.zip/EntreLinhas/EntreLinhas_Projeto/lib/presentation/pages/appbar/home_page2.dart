import 'package:flutter/material.dart';
import '../../../core/theme/colors.dart';
import '../../../core/theme/literatura_data.dart';
import '../../widgets/common.dart';

class HomePage extends StatelessWidget {
  final List<Movement> movements;
  final String userName;
  final int totalCompleted;
  final int totalLessons;
  final Set<String> completedLessons;
  final void Function(Movement movement) onMovement;
  final VoidCallback onQuiz;

  const HomePage({
    super.key,
    required this.movements,
    required this.userName,
    required this.totalCompleted,
    required this.totalLessons,
    required this.completedLessons,
    required this.onMovement,
    required this.onQuiz,
  });

  @override
  Widget build(BuildContext context) {
    final progress = totalLessons == 0
        ? 0.0
        : (totalCompleted / totalLessons).toDouble();

    Movement? continueMovement;
    for (final movement in movements) {
      if (movement.lessons.any((lesson) => !completedLessons.contains(lesson.id))) {
        continueMovement = movement;
        break;
      }
    }
    continueMovement ??= movements.isEmpty ? null : movements.first;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 25, 20, 20),
        children: [
          Text(
            'OLÁ, ${userName.split(' ').first.toUpperCase()}',
            style: const TextStyle(
              color: muted,
              fontSize: 11,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'Literatura Brasileira',
            style: TextStyle(
              color: cream,
              fontSize: 27,
              fontWeight: FontWeight.bold,
            ),
          ),
          const Text(
            'e Portuguesa',
            style: TextStyle(color: muted, fontSize: 15),
          ),
          const SizedBox(height: 20),
          Card(
            color: panel,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Seu progresso',
                        style: TextStyle(
                          color: cream,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '${(progress * 100).round()}%',
                        style: const TextStyle(
                          color: gold,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  LinearProgressIndicator(
                    value: progress,
                    minHeight: 7,
                    borderRadius: BorderRadius.circular(10),
                    backgroundColor: Colors.white10,
                    valueColor: const AlwaysStoppedAnimation<Color>(gold),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '$totalCompleted de $totalLessons aulas concluídas',
                    style: const TextStyle(color: muted, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const SectionTitle('CONTINUE ESTUDANDO'),
          const SizedBox(height: 10),
          if (continueMovement != null)
            MovementContinueCard(
              movement: continueMovement!,
              completedLessons: completedLessons,
              onTap: () => onMovement(continueMovement!),
            ),
          const SizedBox(height: 22),
          const SectionTitle('MOVIMENTOS'),
          const SizedBox(height: 10),
          ...movements.map(
            (movement) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: MovementTile(
                movement: movement,
                onTap: () => onMovement(movement),
              ),
            ),
          ),
          const SizedBox(height: 10),
          AppButton(label: 'Fazer quiz geral', onPressed: onQuiz),
        ],
      ),
    );
  }
}
class MovementsPage extends StatefulWidget {
  final List<Movement> movements;
  final void Function(Movement movement) onMovement;

  const MovementsPage({
    super.key,
    required this.movements,
    required this.onMovement,
  });

  @override
  State<MovementsPage> createState() => _MovementsPageState();
}

class _MovementsPageState extends State<MovementsPage> {
  final searchController = TextEditingController();
  String search = '';

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = widget.movements.where((movement) {
      final value = search.trim().toLowerCase();
      return value.isEmpty ||
          movement.title.toLowerCase().contains(value) ||
          movement.period.toLowerCase().contains(value) ||
          movement.shortDesc.toLowerCase().contains(value);
    }).toList();

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 25, 20, 20),
        children: [
          const SectionTitle('LINHA DO TEMPO'),
          const SizedBox(height: 5),
          const Text(
            'Movimentos Literários',
            style: TextStyle(color: cream, fontSize: 27, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: searchController,
            onChanged: (value) => setState(() => search = value),
            decoration: InputDecoration(
              hintText: 'Buscar movimento...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: search.isEmpty
                  ? null
                  : IconButton(
                      tooltip: 'Limpar busca',
                      onPressed: () {
                        searchController.clear();
                        setState(() => search = '');
                      },
                      icon: const Icon(Icons.clear),
                    ),
              filled: true,
              fillColor: panel,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 15),
          if (filtered.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 40),
              child: Center(
                child: Text('Nenhum movimento encontrado.', style: TextStyle(color: muted)),
              ),
            ),
          ...filtered.map(
            (movement) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: MovementTile(
                movement: movement,
                onTap: () => widget.onMovement(movement),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
