import 'package:flutter/material.dart';
import '../../../core/theme/colors.dart';
import '../../../core/theme/literatura_data.dart';
import '../../widgets/common.dart';

class SplashPage extends StatelessWidget {
  final VoidCallback onContinue;

  const SplashPage({super.key, required this.onContinue});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF00181C), bg],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: double.infinity,
                  constraints: const BoxConstraints(maxWidth: 420),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Image.asset(
                    'assets/logo.png',
                    fit: BoxFit.contain,
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Estude. Leia. Descubra.',
                  style: TextStyle(
                    color: muted,
                    fontSize: 15,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 45),
                AppButton(
                  label: 'Começar a estudar',
                  onPressed: onContinue,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
class LoginPage extends StatefulWidget {
  final void Function(String name) onLogin;
  final VoidCallback onRegister;

  const LoginPage({
    super.key,
    required this.onLogin,
    required this.onRegister,
  });

  @override
  State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool showPassword = false;
  String error = '';

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  void submit() {
    final email = emailController.text.trim();
    final password = passwordController.text;

    if (email.isEmpty) {
      setState(() => error = 'Informe seu e-mail.');
      return;
    }
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email)) {
      setState(() => error = 'Informe um e-mail válido.');
      return;
    }
    if (password.isEmpty) {
      setState(() => error = 'Informe sua senha.');
      return;
    }
    if (password.length < 6) {
      setState(() => error = 'A senha deve ter ao menos 6 caracteres.');
      return;
    }

    String name = emailController.text.split('@').first;
    name = name.replaceAll(RegExp(r'[._-]'), ' ');
    name = name
        .split(' ')
        .where((part) => part.isNotEmpty)
        .map((part) => part[0].toUpperCase() + part.substring(1))
        .join(' ');

    widget.onLogin(name.isEmpty ? 'Estudante' : name);
  }

  @override
  Widget build(BuildContext context) {
    return AuthScaffold(
      title: 'Bem-vindo de volta',
      subtitle: 'Continue sua jornada pela literatura.',
      children: [
        AppTextField(
          controller: emailController,
          label: 'E-mail',
          icon: Icons.mail_outline,
          keyboardType: TextInputType.emailAddress,
        ),
        AppTextField(
          controller: passwordController,
          label: 'Senha',
          icon: Icons.key_outlined,
          obscure: !showPassword,
          suffix: IconButton(
            icon: Icon(
              showPassword ? Icons.visibility_off : Icons.visibility,
            ),
            onPressed: () {
              setState(() => showPassword = !showPassword);
            },
          ),
        ),
        if (error.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Text(
              error,
              style: const TextStyle(color: Colors.redAccent),
            ),
          ),
        AppButton(label: 'Entrar', onPressed: submit),
        const SizedBox(height: 12),
        TextButton(
          onPressed: widget.onRegister,
          child: const Text(
            'Ainda não tenho conta',
            style: TextStyle(color: gold),
          ),
        ),
      ],
    );
  }
}
class RegisterPage extends StatefulWidget {
  final VoidCallback onBack;
  final void Function(String name) onRegister;

  const RegisterPage({
    super.key,
    required this.onBack,
    required this.onRegister,
  });

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}
class _RegisterPageState extends State<RegisterPage> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  bool showPassword = false;
  String error = '';

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }

  void submit() {
    final name = nameController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text;

    if (name.length < 2) {
      setState(() => error = 'Informe seu nome completo.');
      return;
    }
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email)) {
      setState(() => error = 'Informe um e-mail válido.');
      return;
    }
    if (password.length < 6) {
      setState(() => error = 'A senha deve ter ao menos 6 caracteres.');
      return;
    }
    if (password != confirmPasswordController.text) {
      setState(() => error = 'As senhas não coincidem.');
      return;
    }
    widget.onRegister(name);
  }

  @override
  Widget build(BuildContext context) {
    return AuthScaffold(
      title: 'Criar conta',
      subtitle: 'Comece sua jornada pela literatura.',
      back: widget.onBack,
      children: [
        AppTextField(
          controller: nameController,
          label: 'Nome',
          icon: Icons.person_outline,
        ),
        AppTextField(
          controller: emailController,
          label: 'E-mail',
          icon: Icons.mail_outline,
          keyboardType: TextInputType.emailAddress,
        ),
        AppTextField(
          controller: passwordController,
          label: 'Senha',
          icon: Icons.key_outlined,
          obscure: !showPassword,
          suffix: IconButton(
            icon: Icon(
              showPassword ? Icons.visibility_off : Icons.visibility,
            ),
            onPressed: () {
              setState(() => showPassword = !showPassword);
            },
          ),
        ),
        AppTextField(
          controller: confirmPasswordController,
          label: 'Confirmar senha',
          icon: Icons.lock_outline,
          obscure: !showPassword,
        ),
        if (error.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Text(
              error,
              style: const TextStyle(color: Colors.redAccent),
            ),
          ),
        AppButton(label: 'Criar conta', onPressed: submit),
      ],
    );
  }
}
