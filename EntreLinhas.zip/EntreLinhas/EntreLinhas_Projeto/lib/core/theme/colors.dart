import 'package:flutter/material.dart';

const Color bg = Color(0xFF000000);
const Color panel = Color(0xFF071316);
const Color panelDark = Color(0xFF020708);
const Color cyan = Color(0xFF19D9E6);
const Color gold = cyan;
const Color cream = Color(0xFFE9FFFF);
const Color muted = Color(0xFF79A9AD);
const Color green = cyan;
const Color success = cyan;

Color hexColor(String value) {
  final match = RegExp(r'#[0-9a-fA-F]{6}').firstMatch(value);
  if (match == null) return panel;
  return Color(int.parse('FF${match.group(0)!.substring(1)}', radix: 16));
}
