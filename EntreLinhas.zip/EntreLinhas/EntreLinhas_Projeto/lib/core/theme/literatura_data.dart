import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'colors.dart';

class Lesson {
  final String id;
  final String title;
  final String duration;
  final String content;
  final bool locked;

  Lesson({
    required this.id,
    required this.title,
    required this.duration,
    required this.content,
    required this.locked,
  });

  factory Lesson.fromJson(Map<String, dynamic> json) {
    return Lesson(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      duration: json['duration'] as String? ?? '',
      content: json['content'] as String? ?? '',
      locked: json['locked'] as bool? ?? false,
    );
  }
}
class Question {
  final String question;
  final List<String> options;
  final int correct;
  final String explanation;

  Question({
    required this.question,
    required this.options,
    required this.correct,
    required this.explanation,
  });

  factory Question.fromJson(Map<String, dynamic> json) {
    return Question(
      question: json['question'] as String? ?? '',
      options: List<String>.from(json['options'] ?? const <String>[]),
      correct: (json['correct'] as num?)?.toInt() ?? 0,
      explanation: json['explanation'] as String? ?? '',
    );
  }
}
class Movement {
  final String id;
  final String title;
  final String period;
  final String color;
  final String bgColor;
  final String emoji;
  final String shortDesc;
  final String overview;
  final List<String> characteristics;
  final List<String> mainAuthors;
  final List<String> mainWorks;
  final String curiosity;
  final List<Lesson> lessons;
  final List<Question> quiz;

  Movement({
    required this.id,
    required this.title,
    required this.period,
    required this.color,
    required this.bgColor,
    required this.emoji,
    required this.shortDesc,
    required this.overview,
    required this.characteristics,
    required this.mainAuthors,
    required this.mainWorks,
    required this.curiosity,
    required this.lessons,
    required this.quiz,
  });

  factory Movement.fromJson(Map<String, dynamic> json) {
    return Movement(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      period: json['period'] as String? ?? '',
      color: json['color'] as String? ?? '#C9913A',
      bgColor: json['bgColor'] as String? ?? '#162219',
      emoji: json['emoji'] as String? ?? '📚',
      shortDesc: json['shortDesc'] as String? ?? '',
      overview: json['overview'] as String? ?? '',
      characteristics: List<String>.from(json['characteristics'] ?? const <String>[]),
      mainAuthors: List<String>.from(json['mainAuthors'] ?? const <String>[]),
      mainWorks: List<String>.from(json['mainWorks'] ?? const <String>[]),
      curiosity: json['curiosity'] as String? ?? '',
      lessons: (json['lessons'] as List<dynamic>? ?? const [])
          .map((item) => Lesson.fromJson(Map<String, dynamic>.from(item as Map)))
          .toList(),
      quiz: (json['quiz'] as List<dynamic>? ?? const [])
          .map((item) => Question.fromJson(Map<String, dynamic>.from(item as Map)))
          .toList(),
    );
  }

  Color get accent => gold;
  Color get background => const Color(0xFF06272B);
}


Future<List<Movement>> loadMovements() async {
  final raw = await rootBundle.loadString('assets/content.json');
  final decoded = jsonDecode(raw) as Map<String, dynamic>;
  final list = decoded['movements'] as List<dynamic>? ?? const [];
  return list.map((item) => Movement.fromJson(Map<String, dynamic>.from(item as Map))).toList();
}

Future<List<Question>> loadGeneralQuiz() async {
  final raw = await rootBundle.loadString('assets/content.json');
  final decoded = jsonDecode(raw) as Map<String, dynamic>;
  final list = decoded['generalQuiz'] as List<dynamic>? ?? const [];
  return list.map((item) => Question.fromJson(Map<String, dynamic>.from(item as Map))).toList();
}
