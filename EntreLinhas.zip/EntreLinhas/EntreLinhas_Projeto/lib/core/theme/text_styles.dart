import 'package:flutter/material.dart';
import 'colors.dart';

class AppTextStyles {
  static const section = TextStyle(color: muted, fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold);
  static const body = TextStyle(color: cream, height: 1.45);
  static const bodyMuted = TextStyle(color: muted, height: 1.5);
}
