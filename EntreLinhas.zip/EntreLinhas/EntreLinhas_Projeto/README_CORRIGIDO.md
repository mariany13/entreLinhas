# EntreLinhas — versão melhorada

Aplicativo educacional para estudo de Literatura Brasileira e Portuguesa.

## Melhorias realizadas

- Carregamento inicial com indicador de progresso e tela de erro com tentativa novamente.
- Progresso das aulas salvo no dispositivo, para não ser perdido ao fechar o aplicativo.
- Estatísticas de quizzes salvas: quantidade de respostas e percentual de acertos.
- Perfil atualizado com progresso real, acertos e conquistas baseadas no uso.
- Botão de sair da conta no perfil.
- Validação de e-mail e senha no login.
- Cadastro com validação de nome, e-mail, senha e confirmação da senha.
- Busca por movimentos literários.
- Tela inicial mostra automaticamente o movimento que deve ser continuado.
- Aulas bloqueadas respeitam a sequência de estudo e exibem orientação ao usuário.
- Aulas concluídas passam a ser identificadas visualmente.
- Quiz com feedback da resposta e explicação continua funcionando.
- Corrigida a organização dos imports para evitar conflito entre telas com nomes iguais.
- Mantida a identidade visual original do EntreLinhas.

## Executar

No terminal, dentro da pasta do projeto:

```powershell
flutter clean
flutter pub get
flutter run -d chrome
```

O projeto usa `shared_preferences` para salvar o progresso localmente.
